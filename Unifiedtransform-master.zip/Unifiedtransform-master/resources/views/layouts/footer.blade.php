<div class="row border-top-e6 mt-4 ps-4 pt-4">
    <p><em>Built with</em> <i class="bi bi-heart"></i>. License: <a href="https://github.com/changeweb/Unifiedtransform/blob/master/LICENSE" style="text-decoration: none;">GNU General Public License v3.0</a></p>
</div>